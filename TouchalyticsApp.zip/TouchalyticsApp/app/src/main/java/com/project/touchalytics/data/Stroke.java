package com.project.touchalytics.data;

import android.view.MotionEvent;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class Stroke {

    long startTime;
    long endTime;

    List<TouchPoint> points;

    public Stroke(){
        this.points = new ArrayList<>();
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    /**
     * @param event: MotionEvent to add to the stroke
     */
    public void addPointWithEvent(MotionEvent event) {
        TouchPoint point = new TouchPoint(
                event.getX(),
                event.getY(),
                event.getEventTime(),
                event.getPressure(),
                event.getSize()
        );
        points.add(point);
    }

    /**
     *
     * @return the points in the stroke
     */
    public List<TouchPoint> getPoints(){
        return points;
    }

    /**
     * @return a string representation of the stroke
     * */
    @NonNull
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Stroke was:").append(endTime-startTime).append("milliseconds\n");

        for (TouchPoint p : points) {
            sb.append(p.toString()).append("\n");
        }
        return sb.toString();
    }

    /**
    * @param x: x coordinate of the point
    * @param y: y coordinate of the point
    * @param timestamp: timestamp of the point
    * @param pressure: pressure of the point
    * @param size: size of the point
    * */
    public void addPointWithFeatures(float x, float y, long timestamp, float pressure, float size) {
        TouchPoint point = new TouchPoint(x, y, timestamp, pressure, size);
        points.add(point);
    }

    /**
     * @return the area of the stroke covered
     * */
    public float calculateMidStrokeArea() {

        if (points.isEmpty()) return 0;

        float minX = points.get(0).x;
        float maxX = points.get(0).x;

        float minY = points.get(0).y;
        float maxY = points.get(0).y;

        for (TouchPoint point : points) {
            if (point.x < minX) minX = point.x;
            if (point.x > maxX) maxX = point.x;

            if (point.y < minY) minY = point.y;
            if (point.y > maxY) maxY = point.y;
        }

        return (maxX - minX) * (maxY - minY);  // Bounding box area
    }

    /**
     * @return the distance between the two points
     * */
    private float calculateDistance(TouchPoint p1, TouchPoint p2) {
        return (float) Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
    }

    /**
     * @param percentile : the percentile to calculate
     * @return the velocity percentile of the stroke
     * */
    public float calculatePairwiseVelocityPercentile(int percentile) {

        if (points.size() < 2) {
            return 0;
        }

        List<Float> velocities = new ArrayList<>();

        for (int i = 1; i < points.size(); i++) {
            float distance = calculateDistance(points.get(i-1), points.get(i));
            float timeDelta = points.get(i).timestamp - points.get(i-1).timestamp;

            if (timeDelta > 0) {
                velocities.add(distance / timeDelta);
            }
        }

        if (velocities.isEmpty()) {
            return 0;
        }

        velocities.sort(Float::compare);

        int index = Math.round((velocities.size() - 1) * percentile / 100.0f);

        return velocities.get(index);
    }

    /**
     * @return : the average velocity of the stroke
     * */
    public float calculateMidStrokePressure() {
        if (points.size() < 3) return 0;

        int midStart = points.size() / 4;
        int midEnd = 3 * points.size() / 4;

        float totalPressure = 0;
        int count = 0;
        for (int i = midStart; i <= midEnd; i++) {
            totalPressure += points.get(i).pressure;
            count++;
        }

        return totalPressure / count;
    }

    /**
     * @return : the direction of the stroke
     * */
    public float calculateDirectionEndToEnd() {
        if (points.size() < 2) return 0;

        TouchPoint start = points.get(0);
        TouchPoint end = points.get(points.size() - 1);

        return (float) Math.atan2(end.y - start.y, end.x - start.x);
    }

    /**
     * All getters methods below this point for the coordinates
     * */

    public float getStartX() {
        return points.get(0).x;
    }

    public float getStopX() {
        return points.get(points.size() - 1).x;
    }

    public float getStartY() {
        return points.get(0).y;
    }

    public float getStopY() {
        return points.get(points.size() - 1).y;
    }

    /***
     * @return the average direction of the stroke
     * calculated by taking the inverse tan of the slope between each point
     */
    public float calculateAverageDirection() {
        if (points.size() < 2) return 0;

        float totalDirection = 0;
        int count = 0;

        for (int i = 1; i < points.size(); i++) {
            totalDirection += (float) Math.atan2(points.get(i).y - points.get(i-1).y, points.get(i).x - points.get(i-1).x);
            count++;
        }

        return totalDirection / count;
    }

    public float calculateAverageVelocity() {
        if (points.size() < 2) return 0;

        float totalDistance = 0;
        for (int i = 1; i < points.size(); i++) {
            totalDistance += calculateDistance(points.get(i-1), points.get(i));
        }

        long totalTime = points.get(points.size() - 1).timestamp - points.get(0).timestamp;
        return totalDistance / totalTime;
    }

}