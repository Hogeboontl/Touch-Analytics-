package com.project.touchalytics;

import com.google.gson.JsonObject;
import com.project.touchalytics.data.Features;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.Path;

public class RetrofitClient {

    private static Retrofit retrofit = null;

    public static Retrofit getClient() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.SERVER_BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create()) // Convert JSON to Java object
                    .build();
        }
        return retrofit;
    }

    public interface ApiService {
        // Send swipe features for classification
        @POST("/authenticate/{userID}")
        Call<JsonObject> sendFeatures(@Path("userID") int userID, @Body Features features);
    }

}
