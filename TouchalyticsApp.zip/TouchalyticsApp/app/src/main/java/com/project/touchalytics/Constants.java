package com.project.touchalytics;

public class Constants {

    public static final String SERVER_BASE_URL = "http://10.2.1.251:5001/";
    public static final String HOME_WEBSITE = "https://www.nytimes.com/";
    public static final Integer MIN_STROKE_COUNT = 50;
}
