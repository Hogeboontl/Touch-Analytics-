package com.project.touchalytics.data;

import androidx.annotation.NonNull;

public class TouchPoint {
    float x;
    float y;
    long timestamp;
    float pressure;
    float size;

    TouchPoint(float x, float y, long timestamp, float pressure, float size) {
        this.x = x;
        this.y = y;
        this.timestamp = timestamp;
        this.pressure = pressure;
        this.size = size;
    }

    @NonNull
    @Override
    public String toString() {
        return "TouchPoint{" +
                "x=" + x +
                ", y=" + y +
                ", timestamp=" + timestamp +
                ", pressure=" + pressure +
                ", size=" + size +
                '}';
    }
}