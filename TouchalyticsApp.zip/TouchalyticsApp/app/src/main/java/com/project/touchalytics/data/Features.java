package com.project.touchalytics.data;

public class Features {
    private int userID;
    private float strokeDuration;
    private float midStrokeArea;
    private float midStrokePressure;
    private float directionEndToEnd;
    private float averageDirection;
    private float averageVelocity;
    private float pairwiseVelocityPercentile;
    private float startX;
    private float stopX;
    private float startY;
    private float stopY;

    public Features() {}

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public float getStrokeDuration() {
        return strokeDuration;
    }

    public void setStrokeDuration(float strokeDuration) {
        this.strokeDuration = strokeDuration;
    }

    public float getMidStrokeArea() {
        return midStrokeArea;
    }

    public void setMidStrokeArea(float midStrokeArea) {
        this.midStrokeArea = midStrokeArea;
    }

    public float getMidStrokePressure() {
        return midStrokePressure;
    }

    public void setMidStrokePressure(float midStrokePressure) {
        this.midStrokePressure = midStrokePressure;
    }

    public float getDirectionEndToEnd() {
        return directionEndToEnd;
    }

    public void setDirectionEndToEnd(float directionEndToEnd) {
        this.directionEndToEnd = directionEndToEnd;
    }

    public float getAverageDirection() {
        return averageDirection;
    }

    public void setAverageDirection(float averageDirection) {
        this.averageDirection = averageDirection;
    }

    public float getAverageVelocity() {
        return averageVelocity;
    }

    public void setAverageVelocity(float averageVelocity) {
        this.averageVelocity = averageVelocity;
    }

    public float getPairwiseVelocityPercentile() {
        return pairwiseVelocityPercentile;
    }

    public void setPairwiseVelocityPercentile(float pairwiseVelocityPercentile) {
        this.pairwiseVelocityPercentile = pairwiseVelocityPercentile;
    }

    public float getStartX() {
        return startX;
    }

    public void setStartX(float startX) {
        this.startX = startX;
    }

    public float getStopX() {
        return stopX;
    }

    public void setStopX(float stopX) {
        this.stopX = stopX;
    }

    public float getStartY() {
        return startY;
    }

    public void setStartY(float startY) {
        this.startY = startY;
    }

    public float getStopY() {
        return stopY;
    }

    public void setStopY(float stopY) {
        this.stopY = stopY;
    }
}